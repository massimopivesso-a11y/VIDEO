# PIVESSO — Guida al preventivo Legend

## Cosa contiene il video

Sorgente: «Preventivo Legend - 16 ottobre.mp4», 1280 × 720, 30 fps, durata 01:37,75. Il contenuto è una registrazione del sito e del configuratore di preventivi. Non mostra taglio, stampa, cucitura o altre lavorazioni fisiche. Le maglie illustrate nel catalogo sono esempi di personalizzazione, non il prodotto realizzato durante questa registrazione.

La traccia audio decodificata contiene silenzio digitale per tutta la durata: nessun parlato, musica o suono di lavorazione. Non servono sottotitoli di trascrizione. I testi incorporati sono spiegazioni editoriali delle azioni visibili.

## Analisi dall’inizio alla fine

Tempi riferiti al video originale. I confini delle fasi, spesso attraversate con scorrimenti continui, sono arrotondati al secondo.

| Inizio–fine | Cosa si vede | Operazione riconoscibile | Testo suggerito |
|---|---|---|---|
| 00:00–00:06 | Homepage con immagini di motocross, bici e sci | Visualizzazione della presentazione del sito | L’abbigliamento del tuo team parte da qui. |
| 00:06–00:10 | Riquadri dedicati agli sport | Accesso alla sezione sportiva | Scegli il tuo sport. |
| 00:10–00:17 | Sezione Moto e categorie, fra cui MX-Enduro | Navigazione verso il catalogo MX-Enduro | Scopri la categoria MX-Enduro. |
| 00:17–00:43 | Scorrimento di maglie, pantaloni, gilet e giacche; ritorni fra le schede | Consultazione del catalogo e dei modelli | Esplora i modelli disponibili. |
| 00:43–00:49 | Scheda Maglia Legend, fronte e retro dell’esempio viola | Consultazione della scheda prodotto | Maglia Legend: un esempio di personalizzazione. |
| 00:49–00:56 | Pagina sulla personalizzazione con pulsante del configuratore | Navigazione verso la creazione del preventivo | Passa al preventivo online. |
| 00:56–00:59 | Pagina «Crea il tuo preventivo» e scelta sport | Avvio del configuratore, selezione Moto | Scegli lo sport. |
| 00:59–01:01 | Passaggi del configuratore: categoria e tipologia | Selezioni che portano a Moto / MX-Enduro / Maglie | Scegli categoria e tipologia. |
| 01:01–01:03 | Elenco dei modelli di maglia, selezione Legend | Scelta del modello | Seleziona la maglia Legend. |
| 01:03–01:10 | Quantità e incremento del numero di capi fino a 10; opzioni logo sottostanti | Impostazione della quantità | Imposta il numero di capi. |
| 01:10–01:17 | Opzioni per presenza del logo Pivesso: standard, sponsor, rimozione | Esplorazione e selezione delle opzioni logo | Scegli come usare il logo Pivesso. |
| 01:17–01:21 | Opzioni colore standard e fluo, pulsante «Calcola» | Scelta colore e calcolo | Colori standard oppure fluo. |
| 01:21–01:26 | Prodotto aggiunto e dettaglio economico | Verifica del prodotto nel preventivo | Controlla il riepilogo del capo. |
| 01:26–01:32 | «Costi stampa», opzioni «Nuovo progetto» e «Aggiornamento progetto»; selezioni e aggiornamento totale | Scelta dell’opzione di elaborazione grafica. Il video non mostra una stampa materiale. | Scegli l’opzione per la grafica. |
| 01:32–01:37,75 | Riepilogo prodotti, rifiniture, totale e pulsanti PDF, stampa, email e copia testo | Visualizzazione finale del preventivo | Controlla il preventivo finale. |

Non si vede un ordine inviato, un PDF effettivamente scaricato o una mail spedita. Il riepilogo finale è il risultato del percorso digitale. Gli importi sono quelli dell’esempio registrato, non un’offerta valida per ogni cliente.

## Montaggio consegnato

Reel: 36,3 secondi. Storia: 22 secondi, in un unico file. Entrambi in MP4 H.264, 1080 × 1920, 30 fps, con testi incorporati. La sorgente a 720p viene ingrandita: l’esportazione a 1080p non recupera dettaglio assente dall’originale.

Apertura sulla maglia Legend; passaggi successivi in ordine logico. Eliminati i lunghi scorrimenti e ritorni del catalogo. Alcune azioni sono accelerate; la scelta del modello nel Reel è rallentata per facilitarne la comprensione. La chiusura torna all’esempio di maglia e invita a scrivere in DM.

Schermate rifilate e ingrandite mantenendo le proporzioni, su fondo nero, titoli bianchi e accenti giallo lime. Le spiegazioni stanno fuori dalla finestra del video. Nessun logo autonomo aggiunto, ricreato o ritoccato; restano quelli già presenti nel prodotto filmato. Non era allegato un file del logo ufficiale.

La copertina è 1080 × 1920: titolo, modello e immagine centrale sono collocati per rimanere leggibili anche nei ritagli centrali quadrati e 3:4. Quando la scegli su Instagram, mantieni il ritaglio centrato. I comandi dell’app possono cambiare posizione: controlla l’anteprima prima della pubblicazione.

Le scalette con tempi esatti di origine e destinazione e testi sono nei file Reel_montaggio.json e Storia_montaggio.json.

## Musica — da aggiungere, non presente nei file

Gli MP4 consegnati non contengono musica né una traccia audio: l’originale è silenzioso e non è stata reperita una traccia con licenza commerciale verificabile.

Direzione musicale: electro-sport strumentale, 115–125 BPM, batteria asciutta, basso ritmico e synth essenziali; senza voce. Evitare un crescendo lungo: l’energia deve partire subito. Al tempo indicativo di 120 BPM, usare un accento all’apertura e sulla CTA; i tagli interni sono guidati dalla comprensione delle operazioni, senza una sincronizzazione musicale già effettuata.

Per inserirla: procurarsi una traccia autorizzata per il profilo aziendale e l’uso commerciale previsto, per esempio dalla Meta Sound Collection, verificando le condizioni aggiornate del brano e degli impieghi ammessi, comprese eventuali sponsorizzazioni. Non presumere che una canzone disponibile nella libreria Instagram sia autorizzata per qualsiasi uso aziendale.

Importare la traccia nell’editor, tagliarla alla durata del video, applicare circa 0,2 secondi di ingresso e 0,5 secondi di uscita e riesportare. Livello orientativo del mix finale: −16 / −14 LUFS integrati, picco vero massimo −1 dBTP. Non ci sono voci da proteggere in questi file. In alternativa, se il brano autorizzato è disponibile per l’account nel flusso di pubblicazione, aggiungerlo da «Audio/Musica» su Instagram e ricontrollare l’anteprima. La selezione del brano e il controllo della relativa licenza restano da effettuare.

## Caption pronta da copiare

Il tuo team ha uno stile tutto suo. Anche l’abbigliamento può raccontarlo. 🟡

Nel video ti mostriamo il percorso per configurare un preventivo PIVESSO: sport, modello, quantità, opzioni logo e colori, fino al riepilogo finale. Qui l’esempio è la maglia Legend per MX-Enduro.

Gli importi mostrati sono quelli della simulazione e dipendono dalle opzioni selezionate.

Vuoi creare l’abbigliamento del tuo team? Scrivici in DM con sport e numero di capi: partiamo da lì.

#Pivesso #AbbigliamentoSportivoPersonalizzato #AbbigliamentoTeam #MagliePersonalizzate #Motocross #Enduro

## Testo breve per accompagnare la storia

Il prossimo look del tuo team parte da qui. Scopri il preventivo online e scrivici in DM per il tuo progetto. 🟡

## Verifica

Controlli completati: MP4 H.264, 1080 × 1920, 30 fps; Reel 1.089 fotogrammi / 36,3 secondi, Storia 660 fotogrammi / 22 secondi. Decodifica completa di entrambi senza errori. Ispezionati i fotogrammi rappresentativi di tutti i segmenti, verificando corrispondenza dei testi, ortografia e assenza di sovrapposizioni con le schermate. Controllati i ritagli e la posizione dei testi della copertina. Nessuna traccia audio incorporata: non è stato eseguito né dichiarato un mix musicale. I piccoli testi nativi del sito non sostituiscono le spiegazioni grandi sovraimpresse. Nessuna trascrizione inventata e nessuna lavorazione fisica attribuita alle immagini. Nessun intervento sui file del repository VIDEO.


## Scaletta esatta dei file esportati

### Reel

| Tempo nel montaggio | Estratto originale | Testo principale |
|---|---|---|
| 00:00.0–00:03.0 | 00:43.5–00:46.5 | Il tuo team. Da dove si parte? |
| 00:03.0–00:06.6 | 00:57.4–01:01.0 | Scegli sport e categoria |
| 00:06.6–00:09.6 | 01:01.0–01:03.0 | Seleziona la maglia Legend |
| 00:09.6–00:13.6 | 01:05.0–01:10.0 | Imposta la quantità |
| 00:13.6–00:17.6 | 01:10.0–01:16.8 | Scegli come usare il logo Pivesso |
| 00:17.6–00:20.8 | 01:17.3–01:20.5 | Colori standard oppure fluo |
| 00:20.8–00:24.8 | 01:20.5–01:25.0 | Calcola e controlla il prodotto |
| 00:24.8–00:28.8 | 01:25.5–01:32.0 | Scegli l’opzione per la grafica |
| 00:28.8–00:32.8 | 01:32.5–01:37.5 | Controlla il preventivo finale |
| 00:32.8–00:36.3 | 00:43.5–00:47.0 | Vuoi vestire il tuo team? |

### Storia

| Tempo nel montaggio | Estratto originale | Testo principale |
|---|---|---|
| 00:00.0–00:02.5 | 00:43.5–00:46.0 | Il tuo team. Il tuo stile. |
| 00:02.5–00:06.5 | 00:58.0–01:03.0 | Sport, categoria e modello |
| 00:06.5–00:12.0 | 01:09.5–01:20.5 | Quantità, logo e colori |
| 00:12.0–00:15.5 | 01:25.5–01:32.0 | Scegli l’opzione per la grafica |
| 00:15.5–00:18.5 | 01:33.0–01:36.0 | Controlla il riepilogo |
| 00:18.5–00:22.0 | 00:43.5–00:47.0 | Vuoi vestire il tuo team? |
